import java.io.IOException;
import java.net.*;

public class RunChat {

	public static void main(String[] args) {
		new ServerFrame().start();
		new ClientFrame().start();
		
	}
	
}
