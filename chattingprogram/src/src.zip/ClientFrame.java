import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;

public class ClientFrame extends Thread{
	Socket cSocket;
	Frame cFrame;
	TextArea ta;
	TextField tf;
	String sendMessage;
	
	public ClientFrame() {
		try{
			Socket cSocket = new Socket("192.168.0.14", 3333);
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		cFrame = new Frame("Client");
		cFrame.setBounds(1000, 300, 600, 600);
		
		ta = new TextArea();
		ta.setEditable(false);
		ta.setBackground(Color.LIGHT_GRAY);
		
		tf = new TextField();
		tf.requestFocus();
		
		cFrame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent we) {
				try(PrintWriter pw = new PrintWriter(cSocket.getOutputStream(), true)) {
					pw.println("������� ������ ���������ϴ�.");
					cSocket.close();
				} catch(IOException e) {
					e.printStackTrace();
				}
			}
		});
		
		cFrame.add(ta, "Center");
		cFrame.add(tf, "South");
		cFrame.setVisible(true);
		sendMessage(); recieveMessage();
	}
	
	public void sendMessage() {
		tf.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				sendMessage = ae.getActionCommand();
				try(PrintWriter pw = new PrintWriter(cSocket.getOutputStream(), true)) {
					pw.println(sendMessage);
				} catch(IOException e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void recieveMessage() {
		String recieveMessage;
		try(BufferedReader br = new BufferedReader(new InputStreamReader(cSocket.getInputStream()))) {
			while(true) {
				recieveMessage = br.readLine();
				ta.append("���� : " + recieveMessage);
			}
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
}









