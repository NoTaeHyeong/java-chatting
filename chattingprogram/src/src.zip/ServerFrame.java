import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class ServerFrame extends Thread{
	Socket sSocket;
	Frame sFrame;
	TextArea ta;
	TextField tf;
	String sendMessage;
	
	public ServerFrame() {
		try{
			ServerSocket serverSocket = new ServerSocket(3333);
			sSocket = serverSocket.accept();
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		sFrame = new Frame("Server");
		sFrame.setBounds(300, 300, 600, 600);
		
		ta = new TextArea();
		ta.setEditable(false);
		ta.setBackground(Color.LIGHT_GRAY);
		
		tf = new TextField();
		tf.requestFocus();
		
		sFrame.add(ta, "Center");
		sFrame.add(tf, "South");
		sFrame.setVisible(true);
		sendMessage(); recieveMessage();
	
	}
	
	public void sendMessage() {
		tf.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				sendMessage = ae.getActionCommand();
				
				try(PrintWriter pw = new PrintWriter(sSocket.getOutputStream(), true)) {
					pw.println(sendMessage);
				} catch(IOException e) {
					e.printStackTrace();
				}
				
				ta.append(sendMessage);
				tf.getText(); tf.setText("");
			}
		});
		
	}
	
	public void recieveMessage() {
		String recieveMessage;
		
		try(BufferedReader br = new BufferedReader(new InputStreamReader(sSocket.getInputStream()))) {
			while(true) {
				recieveMessage = br.readLine();
				if(recieveMessage == null) {
					ta.append("������� ������ ���������ϴ�.");
				}
				ta.append("���� : " + recieveMessage);
			}
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
}









